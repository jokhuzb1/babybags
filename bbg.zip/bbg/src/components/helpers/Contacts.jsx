import React from 'react'
import { Instagram } from 'react-bootstrap-icons';
import { Telegram } from 'react-bootstrap-icons';
export default function Contacts() {
  return (
    <div className="social ">
        <h5>Мы на сваязи 24/7 и соц сетях чтобы ускорить процесс доставки и заказа</h5>
        <h5>Номер: <a href='tel:+998973705655'>+998973705655</a></h5>
        <h5>Почта: <a href='mailto:babybag23@mail.ru'>babybag23@mail.ru</a></h5>
        <h5>Телеграм: <a href='https://t.me/The_445'>< Telegram/></a></h5>
        <h5>Инстаграм: <a href='https://instagram.com/babyway23?igshid=NGExMmI2YTkyZg=='><Instagram/></a></h5>
       
        
    </div>
  )
}
